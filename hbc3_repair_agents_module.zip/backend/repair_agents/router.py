from fastapi import APIRouter, HTTPException

from .schemas import DiagnosticReport, FixProposal, RepairResult, AuditReport
from .diagnostic_agent import DiagnosticAgent
from .repair_agent import RepairAgent
from .audit_agent import AuditAgent
from .logs import get_logs


router = APIRouter(tags=["Repair Agents"])


@router.post("/diagnose", response_model=DiagnosticReport)
async def diagnose_system():
    agente = DiagnosticAgent()
    return await agente.run()


@router.post("/propose-fix", response_model=FixProposal)
async def propose_fix():
    agente_diag = DiagnosticAgent()
    diagnostico = await agente_diag.run()

    agente_rep = RepairAgent()
    return agente_rep.propose_fix(diagnostico)


@router.post("/apply-fix", response_model=RepairResult)
async def apply_fix(propuesta: FixProposal):
    agente_rep = RepairAgent()

    try:
        if hasattr(propuesta, "model_dump"):
            propuesta_dict = propuesta.model_dump()
        else:
            propuesta_dict = propuesta.dict()

        return agente_rep.apply_fix(propuesta_dict)

    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc))

    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@router.post("/audit", response_model=AuditReport)
async def audit_system():
    agente = AuditAgent()
    return await agente.run()


@router.get("/logs")
async def fetch_logs():
    return {"logs": get_logs()}
