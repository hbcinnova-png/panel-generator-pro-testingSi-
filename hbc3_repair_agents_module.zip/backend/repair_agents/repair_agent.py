import os
from typing import Dict, List, Optional

from .logs import log_action
from .safety import SafetyProtocol, is_safe_relative_path


class RepairAgent:
    """
    Agente reparador HBC3.

    Regla:
    - No aplica parches falsos.
    - No toca producción.
    - Solo modifica archivos si existe una reparación concreta y segura.
    """

    def propose_fix(self, diagnostico: Dict) -> Dict:
        log_action("REPAIR", "Propuesta", "Evaluando diagnóstico")

        errores = diagnostico.get("errores_detectados", [])
        rutas_rotas = diagnostico.get("rutas_rotas", [])

        archivos: List[str] = []
        descripcion = "No se requiere acción."
        requiere_reinicio = False

        main_file = self._find_main_file()

        if "/api/v1/repair/logs" in rutas_rotas:
            if main_file:
                archivos.append(main_file)
                descripcion = (
                    "Registrar el router real de repair_agents en el archivo principal "
                    "de FastAPI usando include_router con prefijo /api/v1/repair."
                )
                requiere_reinicio = True
            else:
                descripcion = (
                    "No se encontró archivo principal FastAPI. Reparación bloqueada "
                    "hasta localizar main.py, backend/main.py o backend/api.py."
                )

        elif rutas_rotas:
            descripcion = (
                "Hay rutas rotas externas al módulo repair_agents. No aplicar parche automático. "
                "Primero revisar routers reales de users/panels y autenticación."
            )
            if main_file:
                archivos.append(main_file)

        elif errores:
            descripcion = (
                "Hay errores, pero no hay una ruta rota segura para reparación automática. "
                "Revisar logs antes de tocar código."
            )

        return {
            "archivos_a_modificar": archivos,
            "descripcion_parche": descripcion,
            "requiere_reinicio": requiere_reinicio,
        }

    def apply_fix(self, propuesta: Dict) -> Dict:
        if SafetyProtocol.is_production():
            log_action("REPAIR", "Bloqueo", "Intento de parche en producción detenido")
            return {
                "status": "BLOQUEO_REAL",
                "archivos_modificados": [],
                "backup_creado": False,
                "logs": ["No se pueden aplicar parches automáticos en producción."],
            }

        descripcion = propuesta.get("descripcion_parche", "")
        archivos = propuesta.get("archivos_a_modificar", [])

        if not archivos:
            log_action("REPAIR", "Bloqueo", "No hay archivos seguros para modificar")
            return {
                "status": "SIN_CAMBIOS",
                "archivos_modificados": [],
                "backup_creado": False,
                "logs": ["No hay archivos seguros para modificar."],
            }

        if "repair_agents" not in descripcion:
            log_action("REPAIR", "Bloqueo", "Parche no específico de repair_agents")
            return {
                "status": "BLOQUEO_REAL",
                "archivos_modificados": [],
                "backup_creado": False,
                "logs": [
                    "El parche propuesto no es específico del módulo repair_agents. "
                    "No se aplica reparación automática."
                ],
            }

        archivos_modificados: List[str] = []
        backup_creado = False
        logs: List[str] = []

        for archivo in archivos:
            if not is_safe_relative_path(archivo):
                logs.append(f"Ruta insegura bloqueada: {archivo}")
                continue

            if not os.path.exists(archivo):
                logs.append(f"Archivo no encontrado: {archivo}")
                continue

            backup_path = SafetyProtocol.create_backup(archivo)
            backup_creado = True

            aplicado = self._ensure_repair_router_registered(archivo)

            if aplicado:
                archivos_modificados.append(archivo)
                logs.append(f"Router repair_agents registrado en {archivo}. Backup: {backup_path}")
                log_action("REPAIR", "Modificación", f"Router registrado en {archivo}")
            else:
                logs.append(f"No se modificó {archivo}: router ya registrado o estructura no compatible.")

        status = "PARCHE_APLICADO" if archivos_modificados else "SIN_CAMBIOS"

        return {
            "status": status,
            "archivos_modificados": archivos_modificados,
            "backup_creado": backup_creado,
            "logs": logs,
        }

    def _find_main_file(self) -> Optional[str]:
        candidatos = [
            "main.py",
            "backend/main.py",
            "app/main.py",
            "backend/api.py",
        ]

        for archivo in candidatos:
            if os.path.exists(archivo):
                return archivo

        return None

    def _ensure_repair_router_registered(self, filepath: str) -> bool:
        with open(filepath, "r", encoding="utf-8") as file:
            contenido = file.read()

        if "repair_agents.router" in contenido and "repair_router" in contenido:
            return False

        if "FastAPI(" not in contenido and "APIRouter(" not in contenido:
            return False

        import_line = "from backend.repair_agents.router import router as repair_router\n"
        include_line = '\napp.include_router(repair_router, prefix="/api/v1/repair", tags=["repair_agents"])\n'

        nuevo_contenido = contenido

        if import_line.strip() not in nuevo_contenido:
            nuevo_contenido = import_line + nuevo_contenido

        if "app.include_router(repair_router" not in nuevo_contenido:
            nuevo_contenido = nuevo_contenido.rstrip() + include_line

        with open(filepath, "w", encoding="utf-8") as file:
            file.write(nuevo_contenido)

        return True
