import os
import shutil
from pathlib import Path
from datetime import datetime
from typing import List

from .logs import log_action


FORBIDDEN_PATH_PARTS = [
    ".env",
    "secrets",
    "credentials",
    "private_key",
    "id_rsa",
    "wp-config.php",
    "database.sql",
    "dump.sql",
]

FORBIDDEN_EXTENSIONS = [
    ".pem",
    ".key",
    ".crt",
]


def is_safe_relative_path(path: str) -> bool:
    if not path or not path.strip():
        return False

    normalized = Path(path)

    if normalized.is_absolute():
        return False

    if ".." in normalized.parts:
        return False

    lowered = path.lower()

    for forbidden in FORBIDDEN_PATH_PARTS:
        if forbidden.lower() in lowered:
            return False

    for extension in FORBIDDEN_EXTENSIONS:
        if lowered.endswith(extension):
            return False

    return True


def filter_safe_files(paths: List[str]) -> List[str]:
    return [path for path in paths if is_safe_relative_path(path)]


class SafetyProtocol:
    @staticmethod
    def is_production() -> bool:
        env = os.getenv("ENVIRONMENT", "staging").lower()
        return env in ["production", "prod"]

    @staticmethod
    def create_backup(filepath: str) -> str:
        if not is_safe_relative_path(filepath):
            raise ValueError(f"Ruta insegura bloqueada: {filepath}")

        if not os.path.exists(filepath):
            raise FileNotFoundError(f"Archivo no encontrado para backup: {filepath}")

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = f"{filepath}.{timestamp}.bak"

        shutil.copy2(filepath, backup_path)
        log_action("SAFETY", "Backup creado", backup_path)

        return backup_path
