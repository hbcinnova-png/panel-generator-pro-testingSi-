import os
from datetime import datetime
from typing import List

LOG_FILE = "repair_audit.log"


def log_action(agente: str, accion: str, detalle: str) -> str:
    timestamp = datetime.utcnow().isoformat()
    mensaje = f"[{timestamp}] [{agente}] {accion} - {detalle}\n"

    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(mensaje)

    return mensaje


def get_logs() -> List[str]:
    if not os.path.exists(LOG_FILE):
        return ["No hay registros de reparación activos."]

    with open(LOG_FILE, "r", encoding="utf-8") as f:
        return f.readlines()
