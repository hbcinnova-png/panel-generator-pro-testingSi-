import os
from typing import Dict, List

import httpx

from .logs import log_action


class DiagnosticAgent:
    def __init__(self, base_url: str = "http://localhost:8000"):
        self.base_url = base_url.rstrip("/")

    async def run(self) -> Dict:
        log_action("DIAGNOSTIC", "Inicio", "Comprobando endpoints internos")

        errores: List[str] = []
        rutas_rotas: List[str] = []
        archivos_sospechosos: List[str] = []

        endpoints = [
            "/health",
            "/api/v1/users",
            "/api/v1/panels",
            "/api/v1/repair/logs",
        ]

        async with httpx.AsyncClient(base_url=self.base_url, timeout=5.0) as client:
            for endpoint in endpoints:
                try:
                    response = await client.get(endpoint)

                    if response.status_code == 404:
                        rutas_rotas.append(endpoint)
                        errores.append(f"404 Not Found en {endpoint}")

                    elif response.status_code == 401:
                        errores.append(f"401 Unauthorized en {endpoint}")

                    elif response.status_code >= 500:
                        errores.append(f"Error {response.status_code} en {endpoint}")

                except Exception as exc:
                    errores.append(f"Fallo de conexión en {endpoint}: {type(exc).__name__}: {exc}")

        candidatos_main = [
            "main.py",
            "backend/main.py",
            "app/main.py",
            "backend/api.py",
        ]

        for archivo in candidatos_main:
            if os.path.exists(archivo):
                archivos_sospechosos.append(archivo)

        if not archivos_sospechosos:
            archivos_sospechosos = ["main.py", "backend/main.py", "backend/api.py"]

        status = "OK" if not errores else "REQUIERE_REPARACION"

        if rutas_rotas:
            causa = "Rutas no registradas, router no incluido o endpoints inexistentes."
            siguiente = "Llamar a /api/v1/repair/propose-fix"
        elif errores:
            causa = "Revisar autenticación, servidor o logs backend."
            siguiente = "Revisar logs antes de aplicar reparación."
        else:
            causa = "No se detectan errores críticos."
            siguiente = "Ninguna."

        log_action("DIAGNOSTIC", "Fin", f"Estado: {status}, errores: {len(errores)}")

        return {
            "status": status,
            "errores_detectados": errores,
            "archivos_sospechosos": archivos_sospechosos,
            "rutas_rotas": rutas_rotas,
            "causa_probable": causa,
            "siguiente_accion": siguiente,
        }
