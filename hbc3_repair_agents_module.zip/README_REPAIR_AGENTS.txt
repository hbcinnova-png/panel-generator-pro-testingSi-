HBC3 repair_agents module

Contenido:
- backend/repair_agents/__init__.py
- backend/repair_agents/router.py
- backend/repair_agents/diagnostic_agent.py
- backend/repair_agents/repair_agent.py
- backend/repair_agents/audit_agent.py
- backend/repair_agents/schemas.py
- backend/repair_agents/logs.py
- backend/repair_agents/safety.py

Instalacion:
1. Copiar la carpeta backend/repair_agents dentro del proyecto HBC3 / Panel Generator Pro.
2. Conectar el router en el archivo principal FastAPI, normalmente backend/api.py o main.py:

from backend.repair_agents.router import router as repair_router
app.include_router(repair_router, prefix="/api/v1/repair", tags=["repair_agents"])

Validacion:
python -m py_compile backend/repair_agents/*.py

Endpoints:
POST /api/v1/repair/diagnose
POST /api/v1/repair/propose-fix
POST /api/v1/repair/apply-fix
POST /api/v1/repair/audit
GET  /api/v1/repair/logs

Estado:
APTO PARA TESTING
NO VALIDADO EN PRODUCCION
