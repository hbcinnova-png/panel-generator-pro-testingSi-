"""HBC3 Repair Agents router.

Standalone, safe endpoints for diagnostic/repair workflow.
They do not touch production code unless a future staging executor is explicitly added.
"""
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from fastapi import APIRouter
from pydantic import BaseModel, Field

router = APIRouter()

class RepairRequest(BaseModel):
    target: Optional[str] = Field(default=None, description="Optional target module or path")
    context: Optional[Dict[str, Any]] = Field(default_factory=dict)

class RepairResponse(BaseModel):
    status: str
    agent: str
    message: str
    timestamp: str
    data: Dict[str, Any] = Field(default_factory=dict)


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()

@router.get("/logs", response_model=RepairResponse)
def get_repair_logs() -> RepairResponse:
    return RepairResponse(
        status="ok",
        agent="HBC3 Repair Logs",
        message="repair_agents router activo",
        timestamp=now_iso(),
        data={"logs": [], "safe_mode": True},
    )

@router.post("/diagnose", response_model=RepairResponse)
def diagnose(payload: RepairRequest) -> RepairResponse:
    return RepairResponse(
        status="ok",
        agent="Agente Diagnostico",
        message="Diagnostico recibido. Sin cambios aplicados.",
        timestamp=now_iso(),
        data={"target": payload.target, "context": payload.context or {}, "changes_applied": False},
    )

@router.post("/propose-fix", response_model=RepairResponse)
def propose_fix(payload: RepairRequest) -> RepairResponse:
    return RepairResponse(
        status="ok",
        agent="Agente Reparador",
        message="Propuesta generada en modo seguro. No se ha modificado codigo.",
        timestamp=now_iso(),
        data={"target": payload.target, "proposal": "Revisar logs, aplicar parche solo en staging", "changes_applied": False},
    )

@router.post("/audit", response_model=RepairResponse)
def audit(payload: RepairRequest) -> RepairResponse:
    return RepairResponse(
        status="ok",
        agent="Agente Auditor/Test",
        message="Auditoria repair_agents activa.",
        timestamp=now_iso(),
        data={"target": payload.target, "checks": ["router_import", "endpoint_mapping", "safe_mode"]},
    )

@router.post("/apply-fix", response_model=RepairResponse)
def apply_fix(payload: RepairRequest) -> RepairResponse:
    return RepairResponse(
        status="blocked",
        agent="Agente Reparador",
        message="BLOQUEO_REAL: apply-fix no ejecuta cambios sin staging autorizado.",
        timestamp=now_iso(),
        data={"target": payload.target, "changes_applied": False, "reason": "safe_mode"},
    )
